package com.cg.retailstore;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class RetailstoreTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void testCalculation() {
		Retailstore retailstore = new Retailstore();
		assertEquals(700, retailstore.Calculation(1000, 1));
	}

	@Test
	void testCalculation1() {
		Retailstore retailstore = new Retailstore();
		assertEquals(900, retailstore.Calculation(1000, 2));
	}

	@Test
	void testCalculation2() {
		Retailstore retailstore = new Retailstore();
		assertEquals(950, retailstore.Calculation(1000, 3));
	}

	@Test
	void testCalculation3() {
		Retailstore retailstore = new Retailstore();
		assertEquals(700, retailstore.Calculation(1000, 1));
	}

}
